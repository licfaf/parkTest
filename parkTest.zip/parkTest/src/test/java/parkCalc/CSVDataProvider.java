package parkCalc;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;

import com.csvreader.CsvReader;;

public class CSVDataProvider {
	
	private static CsvReader reader = null;
	private static Object[][] data = null;
	
	private static int rowCount(String fileName)
	{
		int lines = 0;
		try
		{
			File file = new File(fileName);
			FileReader fr = new FileReader(file);
			LineNumberReader lr = new LineNumberReader(fr);
			while (lr.readLine() != null)
			{
				lines++;
			}
			lr.close();			
		} catch (Exception e) {
			
		}
		return lines;
	}
	
	private static void getData(String fileName)
	{
		int i = 0;
		int rows = rowCount(fileName)-1; //Row Count for the DS Binding
		try
		{
			data = new Object[rows][6];
			reader = new CsvReader(fileName);
			reader.setComment('#');
			reader.setUseComments(true);
			reader.setSkipEmptyRecords(true);
			while (reader.readRecord())
			{
				data[i][0] = reader.get(0);
				data[i][1] = reader.get(1);
				data[i][2] = reader.get(2);
				data[i][3] = reader.get(3);
				data[i][4] = reader.get(4);
				data[i][5] = reader.get(5);
				i++;
			}
		} catch (Exception e) {

		}
	}
	
	public static Object[][] getCSVData(String file)
	{
		String fName = file;
		getData(fName);
		
		return data;
	}
	
}
