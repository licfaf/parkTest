package parkCalc;

import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.assertj.core.api.Assertions;

public class CalcParking {
	
	public void calcParkingNav (WebDriver driver,String Lot, String EntryHour, 
			String EntryDate, String ExitHour, String ExitDate) throws InterruptedException
	{		
		WebDriverWait waitFor = new WebDriverWait(driver, 15);
		waitFor.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//p[contains(text(),'PARKING CALCULATOR')]")));
		
		//Lot Selection
		Select item = new Select(driver.findElement(By.id("Lot")));
		item.selectByVisibleText(Lot);
		
		//Setting entry hour
		driver.findElement(By.id("EntryTime")).clear();
		driver.findElement(By.id("EntryTime")).sendKeys(EntryHour);
		
		//Setting entry date
		driver.findElement(By.id("EntryDate")).clear();
		driver.findElement(By.id("EntryDate")).sendKeys(EntryDate);
		
		//Setting exit hour
		driver.findElement(By.id("ExitTime")).clear();
		driver.findElement(By.id("ExitTime")).sendKeys(ExitHour);
		
		//Setting exit date
		driver.findElement(By.id("ExitDate")).clear();
		driver.findElement(By.id("ExitDate")).sendKeys(ExitDate);
		
		//Calculate parking cost
		driver.findElement(By.xpath("//input[@name='Submit' and @value='Calculate']")).click();
			
		Thread.sleep(2000);
	}
	
	public void calParkingCostValidation (WebDriver driver, String pCost)
	{
		//Validation
		String cost = driver.findElement(By.xpath("//div[.='COST']/../..//span[@class='SubHead']//b")).getText();
		Assertions.assertThat(cost).isEqualTo(pCost);

		Double dCost = Double.parseDouble(cost.replace("$ ", ""));
		System.out.println("El costo es: " + Double.toString(dCost));

		Double compareCost = Double.parseDouble(pCost.replace("$ ", ""));
		Assertions.assertThat(dCost).isEqualTo(compareCost);
	}
}
