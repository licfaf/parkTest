package parkCalc;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;

public class ParkCalcTestShortTerm {
	public WebDriver driver;
//	String Lot = "Short-Term Parking"; //will take the data source information
//	String EntryHour = "10:00"; //will take the data source information
//	String EntryDate = "05/12/2018"; //will take the data source information
//	String ExitHour = "11:00"; //will take the data source information
//	String ExitDate = "05/12/2018"; //will take the data source information
//	String Cost = "$ 2.00"; //will take the data source information
	
	@BeforeClass
	public void beforeClass() 
	{
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://adam.goucher.ca/parkcalc");
		driver.manage().window().maximize();
	}
	
	@DataProvider (name = "dataProvided")
	private Object[][] getData() 
	{
		String file = "./src/test/resources/DataSource/ST_DS.CSV";

		Object[][] datos = CSVDataProvider.getCSVData(file);

		return datos;
	}
	
	@Test (dataProvider = "dataProvided")
	public void shortTermParking(String Lot, String EntryHour, String EntryDate,
			String ExitHour, String ExitDate, String Cost) throws InterruptedException 
	{
		CalcParking Test1 = new CalcParking();
		Test1.calcParkingNav(driver, Lot, EntryHour, EntryDate, ExitHour, ExitDate);
		Test1.calParkingCostValidation(driver, Cost);
	}

	@AfterClass
  	public void afterClass() 
	{
		driver.close();
		driver.quit();
  	}

}