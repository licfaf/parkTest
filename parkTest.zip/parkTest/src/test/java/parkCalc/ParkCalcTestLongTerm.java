package parkCalc;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;

public class ParkCalcTestLongTerm 
{
	public WebDriver driver;
	
	@BeforeClass
	public void beforeClass()
	{
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://adam.goucher.ca/parkcalc");
		driver.manage().window().maximize();
	}
	
	@DataProvider (name = "dataProvided")
	public Object[][] getData()
	{
		String file = "./src/test/resources/DataSource/LT_DS.CSV";
		Object[][] datos = CSVDataProvider.getCSVData(file);
		
		return datos;
	}
	
	@Test (dataProvider = "dataProvided")
	public void longTermParking(String Lot, String EntryHour, String EntryDate,
			String ExitHour, String ExitDate, String Cost) throws InterruptedException 
	{
		CalcParking Test2 = new CalcParking();
		Test2.calcParkingNav(driver, Lot, EntryHour, EntryDate, ExitHour, ExitDate);
		Test2.calParkingCostValidation(driver, Cost);
	}

	@AfterClass
	public void afterClass() 
	{
		driver.close();
		driver.quit();
	}

}
