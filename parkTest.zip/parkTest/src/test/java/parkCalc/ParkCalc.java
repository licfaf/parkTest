package parkCalc;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

public class ParkCalc {
	public WebDriver driver;
	
	@BeforeMethod
	public void beforeMethod() 
	{
		System.setProperty("webdriver.chrome.driver", "./src/test/resources/Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://adam.goucher.ca/parkcalc");
		driver.manage().window().maximize();
	}

	@DataProvider (name = "dataProvided")
	private Object[][] getData() {
		String file = "./src/test/resources/DataSource/CalcPark.CSV";
		
		Object[][] datos = CSVDataProvider.getCSVData(file);
		
		return datos;
	}
	
	@Test (dataProvider = "dataProvided")
	public void parkCalc(String Lot, String EntryHour, String EntryDate,
			String ExitHour, String ExitDate, String Cost) throws InterruptedException 
	{
		CalcParking Test = new CalcParking();
		Test.calcParkingNav(driver, Lot, EntryHour, EntryDate, ExitHour, ExitDate);
		Test.calParkingCostValidation(driver, Cost);
	}

	@AfterMethod
	public void afterMethod() 
	{
		driver.close();
		driver.quit();
	}
}

